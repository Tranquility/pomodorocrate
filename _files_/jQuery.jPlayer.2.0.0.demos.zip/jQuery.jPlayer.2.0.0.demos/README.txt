jPlayer 2.0.0 Demos
-------------------

Upload these files to a server online or place on a localhost server,
otherwise the Flash will encounter security errors if you attempt
to access the HTML files directly.


Directories:
------------

"js": Contains the jPlayer plugin. If you rename/move this, set the {swfPath:"new/path"} appropriately.

"skin": Contains the Blue Monday skin


Related Links:
--------------

For Documentation see:
jPlayer Website: http://www.jplayer.org/

For support requests use:
jPlayer Google Group: http://groups.google.com/group/jplayer/
