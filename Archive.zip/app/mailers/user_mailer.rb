class UserMailer < ActionMailer::Base
  default :from => "notifications@pomodorocrate.com"
  
  def new_account_confirmation_email(user)
    
  end
  
end
