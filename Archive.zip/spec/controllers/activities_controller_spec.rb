require 'spec_helper'

describe ActivitiesController do



end
