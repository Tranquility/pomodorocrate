require "spec_helper"

describe PomodoroMailer do
  pending "add some examples to (or delete) #{__FILE__}"
end
