require 'spec_helper'

describe "pomodoros/index.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
