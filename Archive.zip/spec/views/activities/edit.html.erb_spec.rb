require 'spec_helper'

describe "activities/edit.html.erb" do
  
end
