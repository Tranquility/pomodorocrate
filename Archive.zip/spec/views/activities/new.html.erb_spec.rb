require 'spec_helper'

describe "activities/new.html.erb" do
  
end
