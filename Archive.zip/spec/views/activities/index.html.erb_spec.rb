require 'spec_helper'

describe "activities/index.html.erb" do
  
end
