require 'spec_helper'

describe "activities/show.html.erb" do
  
end
