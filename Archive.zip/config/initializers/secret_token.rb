# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ketchup::Application.config.secret_token = 'bf39236d92c7d1be96a6b00e436e79c8151879c51cf6a2807217e64cab9606053184a84dd0adad173984d8a69b1740235543599faed5fe54cb1c7c968e229dc0'
